package com.virtusa.healthcareproviderservice.exception;

public class JWTNotValidException extends RuntimeException {

}
