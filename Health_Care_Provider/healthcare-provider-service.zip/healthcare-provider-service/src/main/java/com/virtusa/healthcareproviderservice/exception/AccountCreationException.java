package com.virtusa.healthcareproviderservice.exception;

public class AccountCreationException extends RuntimeException {

	public AccountCreationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
