package com.virtusa.healthcareproviderservice.exception;

import lombok.Data;

@Data
public class SuccessModel {
	private String message;
}
