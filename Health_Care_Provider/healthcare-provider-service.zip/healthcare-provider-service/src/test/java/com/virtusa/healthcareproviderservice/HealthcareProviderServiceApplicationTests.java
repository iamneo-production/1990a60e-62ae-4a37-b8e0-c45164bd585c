package com.virtusa.healthcareproviderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareProviderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
